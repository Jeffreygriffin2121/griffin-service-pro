HeatPump Pro v3.4 Passport Dashboard
Upload index.html, style.css, app.js to GitHub root.
