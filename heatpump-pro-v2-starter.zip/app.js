const screens = document.querySelectorAll('.screen');
const tabButtons = document.querySelectorAll('[data-screen]');
const draftsKey = 'heatpumpProDraftsV2';

function showScreen(id){
  screens.forEach(s => s.classList.toggle('active', s.id === id));
  tabButtons.forEach(b => b.classList.toggle('active', b.dataset.screen === id));
  window.scrollTo(0,0);
}
tabButtons.forEach(btn => btn.addEventListener('click', () => showScreen(btn.dataset.screen)));
document.querySelectorAll('.back').forEach(btn => btn.addEventListener('click', () => showScreen('dashboard')));

function getDrafts(){
  return JSON.parse(localStorage.getItem(draftsKey) || '[]');
}
function setDrafts(drafts){
  localStorage.setItem(draftsKey, JSON.stringify(drafts));
  renderDrafts();
}
function formToObject(form){
  const data = Object.fromEntries(new FormData(form).entries());
  data.checks = Array.from(form.querySelectorAll('input[type=checkbox]')).filter(c=>c.checked).map(c=>c.name);
  data.date = new Date().toLocaleString();
  data.id = 'HP-' + Date.now().toString(36).toUpperCase();
  return data;
}
function renderDrafts(){
  const drafts = getDrafts();
  const list = document.getElementById('draftList');
  const customers = document.getElementById('customerList');
  if(!drafts.length){
    list.className = 'list empty'; list.textContent = 'No saved drafts yet.';
    customers.className = 'list empty'; customers.textContent = 'Saved customers will appear here.';
    return;
  }
  list.className = 'list';
  list.innerHTML = drafts.slice().reverse().map(d => `<div class="draft"><b>${d.customer || 'Unnamed customer'}</b><br><small>${d.manufacturer} • ${d.type} • ${d.date}</small></div>`).join('');
  customers.className = 'list';
  customers.innerHTML = drafts.slice().reverse().map(d => `<div class="draft"><b>${d.customer || 'Unnamed customer'}</b><br><small>${d.address || 'No address saved'}</small></div>`).join('');
}
document.getElementById('jobForm').addEventListener('submit', (e)=>{
  e.preventDefault();
  const draft = formToObject(e.target);
  const drafts = getDrafts();
  drafts.push(draft);
  setDrafts(drafts);
  alert('Draft saved on this device.');
  showScreen('dashboard');
});
document.getElementById('exportReport').addEventListener('click', ()=>{
  const draft = formToObject(document.getElementById('jobForm'));
  const text = `HeatPump Pro Service Report\n\nBusiness: Munster Heat Pump Services\nCustomer: ${draft.customer || ''}\nAddress: ${draft.address || ''}\nContact: ${draft.contact || ''}\nManufacturer: ${draft.manufacturer || ''}\nJob Type: ${draft.type || ''}\nModel: ${draft.model || ''}\nSerial: ${draft.serial || ''}\nDate: ${draft.date}\n\nNotes:\n${draft.notes || ''}\n\nChecks:\n${draft.checks.join(', ')}`;
  const blob = new Blob([text], {type:'text/plain'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `HeatPump-Pro-Report-${draft.id}.txt`; a.click();
  URL.revokeObjectURL(url);
});
renderDrafts();

if('serviceWorker' in navigator){
  navigator.serviceWorker.register('service-worker.js').catch(()=>{});
}
